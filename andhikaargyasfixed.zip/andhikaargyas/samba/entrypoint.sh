#!/usr/bin/env bash
set -Eeuo pipefail

SAMBA_USER="${SAMBA_USER:-sambauser}"

if [[ ! "$SAMBA_USER" =~ ^[a-zA-Z0-9_.-]+$ ]]; then
    echo "Nama pengguna Samba tidak valid."
    exit 1
fi

if [[ -z "${SAMBA_PASSWORD:-}" ]]; then
    echo "SAMBA_PASSWORD wajib diatur."
    exit 1
fi

if ! id "$SAMBA_USER" >/dev/null 2>&1; then
    useradd --system --no-create-home --shell /usr/sbin/nologin "$SAMBA_USER"
fi

printf '%s:%s\n' "$SAMBA_USER" "$SAMBA_PASSWORD" | chpasswd
printf '%s\n%s\n' "$SAMBA_PASSWORD" "$SAMBA_PASSWORD" \
    | smbpasswd -s -a "$SAMBA_USER"

mkdir -p /shares/public
chown -R "$SAMBA_USER":"$SAMBA_USER" /shares/public
chmod 0770 /shares/public

testparm -s /etc/samba/smb.conf

exec smbd --foreground --no-process-group
