#!/usr/bin/env bash
set -euo pipefail

FTP_USER="${FTP_USER:-ftpuser}"
FTP_PASSWORD="${FTP_PASSWORD:-}"

if [[ ! "$FTP_USER" =~ ^[a-z_][a-z0-9_-]*$ ]]; then
    echo "Nama pengguna FTP tidak valid."
    exit 1
fi

if [ -z "$FTP_PASSWORD" ]; then
    echo "FTP_PASSWORD belum dikonfigurasi."
    exit 1
fi

if ! id "$FTP_USER" >/dev/null 2>&1; then
    useradd --create-home --shell /bin/bash "$FTP_USER"
fi

printf '%s:%s\n' "$FTP_USER" "$FTP_PASSWORD" | chpasswd

install -d -o "$FTP_USER" -g "$FTP_USER" "/home/$FTP_USER/ftp"
chown "$FTP_USER:$FTP_USER" "/home/$FTP_USER/ftp"
chmod 750 "/home/$FTP_USER/ftp"

exec /usr/sbin/vsftpd /etc/vsftpd.conf
