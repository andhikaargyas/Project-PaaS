<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/vendor/autoload.php';

use App\Models\Database;
use App\Services\Session;

Session::start();

if (empty($_SESSION['user_id'])) {
    header('Location: http://andhikaargyas.sh/login');
    exit;
}

$pdo = Database::connection();

$stmt = $pdo->prepare('SELECT id, name, role FROM users WHERE id = ? LIMIT 1');
$stmt->execute([(int) $_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user || $user['role'] !== 'admin') {
    http_response_code(403);
    exit('403 Forbidden: halaman ini hanya untuk admin.');
}

$summary = $pdo->query("
    SELECT
        COUNT(*) AS total_orders,
        COALESCE(SUM(total_amount), 0) AS total_revenue
    FROM orders
    WHERE status = 'paid'
")->fetch();

$games = $pdo->query("
    SELECT
        g.title,
        SUM(oi.quantity) AS units_sold,
        SUM(oi.quantity * oi.price_at_purchase) AS revenue
    FROM order_items oi
    JOIN orders o ON o.id = oi.order_id
    JOIN games g ON g.id = oi.game_id
    WHERE o.status = 'paid'
    GROUP BY g.id, g.title
    ORDER BY revenue DESC
")->fetchAll();

$recent = $pdo->query("
    SELECT
        o.id,
        u.name AS customer,
        o.total_amount,
        o.paid_at
    FROM orders o
    JOIN users u ON u.id = o.user_id
    WHERE o.status = 'paid'
    ORDER BY o.paid_at DESC, o.id DESC
    LIMIT 20
")->fetchAll();

function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laporan Penjualan - AndhikaArgyas</title>
    <style>
        body{font-family:Arial,sans-serif;background:#10131c;color:#f2f4fa;margin:0;padding:28px}
        main{max-width:1100px;margin:auto}
        a{color:#91baff}
        .cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px}
        .card,section{background:#1b2130;padding:20px;border-radius:12px;margin:16px 0}
        .value{font-size:28px;font-weight:bold;margin-top:12px}
        table{width:100%;border-collapse:collapse}
        th,td{text-align:left;padding:12px;border-bottom:1px solid #353d50}
        .table-wrap{overflow-x:auto}
    </style>
</head>
<body>
<main>
    <p><a href="http://andhikaargyas.sh/">← Kembali ke marketplace</a></p>
    <h1>Laporan Penjualan</h1>
    <p>Login sebagai <?= e($user['name']) ?>.</p>

    <div class="cards">
        <div class="card">
            <div>Total transaksi berhasil</div>
            <div class="value"><?= number_format((int) $summary['total_orders']) ?></div>
        </div>
        <div class="card">
            <div>Total pendapatan</div>
            <div class="value">Rp <?= number_format((float) $summary['total_revenue'], 0, ',', '.') ?></div>
        </div>
    </div>

    <section>
        <h2>Penjualan per game</h2>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Game</th><th>Unit terjual</th><th>Pendapatan</th></tr></thead>
                <tbody>
                <?php if (!$games): ?>
                    <tr><td colspan="3">Belum ada transaksi berstatus paid.</td></tr>
                <?php else: foreach ($games as $game): ?>
                    <tr>
                        <td><?= e($game['title']) ?></td>
                        <td><?= number_format((int) $game['units_sold']) ?></td>
                        <td>Rp <?= number_format((float) $game['revenue'], 0, ',', '.') ?></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <section>
        <h2>20 transaksi terakhir</h2>
        <div class="table-wrap">
            <table>
                <thead><tr><th>ID</th><th>Pelanggan</th><th>Total</th><th>Waktu pembayaran</th></tr></thead>
                <tbody>
                <?php if (!$recent): ?>
                    <tr><td colspan="4">Belum ada transaksi berstatus paid.</td></tr>
                <?php else: foreach ($recent as $order): ?>
                    <tr>
                        <td>#<?= e($order['id']) ?></td>
                        <td><?= e($order['customer']) ?></td>
                        <td>Rp <?= number_format((float) $order['total_amount'], 0, ',', '.') ?></td>
                        <td><?= e($order['paid_at'] ?? '-') ?></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>
</body>
</html>
