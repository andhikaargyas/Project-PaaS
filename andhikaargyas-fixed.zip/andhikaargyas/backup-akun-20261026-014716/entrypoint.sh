#!/usr/bin/env bash
set -euo pipefail

MAIL_USERS="${MAIL_USERS:-direktur manager karyawan}"

for username in $MAIL_USERS; do
    case "$username" in
        (*[!a-zA-Z0-9_-]*|"")
            echo "Nama akun email tidak valid."
            exit 1
            ;;
    esac

    if ! id "$username" >/dev/null 2>&1; then
        useradd -m -s /usr/sbin/nologin "$username"
    fi

    env_name="MAIL_PASSWORD_${username^^}"
    password="$(printenv "$env_name" || true)"

    if [ -z "$password" ]; then
        echo "Environment $env_name belum diisi."
        exit 1
    fi

    printf '%s:%s\n' "$username" "$password" | chpasswd

    install -d -o "$username" -g mail \
        "/home/$username/Maildir" \
        "/home/$username/Maildir/cur" \
        "/home/$username/Maildir/new" \
        "/home/$username/Maildir/tmp"
done

exec /usr/bin/supervisord -c /etc/supervisor/conf.d/mail.conf
