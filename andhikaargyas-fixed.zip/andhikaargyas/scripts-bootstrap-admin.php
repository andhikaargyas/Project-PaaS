<?php
declare(strict_types=1);

$required = ['ADMIN_NAME', 'ADMIN_EMAIL', 'ADMIN_PASSWORD'];

foreach ($required as $key) {
    if (!isset($_ENV[$key]) && getenv($key) === false) {
        fwrite(STDERR, "Konfigurasi {$key} belum tersedia.\n");
        exit(1);
    }
}

$name = trim((string) (getenv('ADMIN_NAME') ?: $_ENV['ADMIN_NAME']));
$email = mb_strtolower(trim((string) (getenv('ADMIN_EMAIL') ?: $_ENV['ADMIN_EMAIL'])));
$password = (string) (getenv('ADMIN_PASSWORD') ?: $_ENV['ADMIN_PASSWORD']);

if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 12) {
    fwrite(STDERR, "Nama/email tidak valid atau password kurang dari 12 karakter.\n");
    exit(1);
}

$host = getenv('DB_HOST') ?: 'db';
$database = getenv('DB_DATABASE') ?: 'marketplace';
$username = getenv('DB_USERNAME') ?: 'root';
$dbPassword = getenv('DB_PASSWORD');

if ($dbPassword === false) {
    fwrite(STDERR, "DB_PASSWORD tidak tersedia pada environment.\n");
    exit(1);
}

$pdo = new PDO(
    "mysql:host={$host};dbname={$database};charset=utf8mb4",
    $username,
    $dbPassword,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
);

$stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
$stmt->execute([$email]);
$userId = $stmt->fetchColumn();

if ($userId !== false) {
    $stmt = $pdo->prepare("UPDATE users SET role = 'admin' WHERE id = ?");
    $stmt->execute([$userId]);
    echo "Role akun admin telah dipastikan.\n";
} else {
    $stmt = $pdo->prepare(
        "INSERT INTO users (name, email, password_hash, role)
         VALUES (?, ?, ?, 'admin')"
    );
    $stmt->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT)]);
    echo "Akun admin berhasil dibuat.\n";
}
