#!/usr/bin/env bash
set -Eeuo pipefail

cd "$(dirname "$0")"

echo "========================================"
echo "   ANDHIKAARGYAS SERVER"
echo "========================================"

# 1. Periksa file konfigurasi
if [[ ! -f .env ]]; then
    echo "ERROR: File .env tidak ditemukan."
    exit 1
fi

# 2. Periksa Docker
if ! command -v docker >/dev/null 2>&1; then
    echo "ERROR: Docker belum terpasang."
    exit 1
fi

if ! docker info >/dev/null 2>&1; then
    echo "ERROR: Docker tidak aktif atau akses ditolak."
    exit 1
fi

# 3. Validasi konfigurasi Compose
echo
echo "[1/3] Memvalidasi Docker Compose..."
docker compose config -q
echo "Konfigurasi Compose valid."

# 4. Build dan jalankan layanan
echo
echo "[2/3] Build dan menjalankan container..."
docker compose up -d --build

# Pastikan akun admin tersedia
echo '[3/4] Memastikan akun admin...'
until docker compose exec -T db sh -lc 'mariadb-admin ping -h 127.0.0.1 -u"$MARIADB_USER" -p"$MARIADB_PASSWORD" --silent' >/dev/null 2>&1; do sleep 2; done
docker compose exec -T app php /var/www/app/public/create-admin.php

# 5. Tampilkan status
echo
echo "[3/3] Status container:"
docker compose ps

echo
echo "Perintah Compose selesai."
echo "Periksa status container dan log jika ada yang gagal."
