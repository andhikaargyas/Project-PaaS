<?php
declare(strict_types=1);

require dirname(__DIR__) . '/vendor/autoload.php';

use App\Models\Database;

date_default_timezone_set(getenv('TZ') ?: 'Asia/Jakarta');

$directory = '/var/www/reports';
if (!is_dir($directory) || !is_writable($directory)) {
    fwrite(STDERR, "Folder laporan tidak tersedia atau tidak bisa ditulis.\n");
    exit(1);
}

$pdo = Database::connection();

$summary = $pdo->query("
    SELECT
        COUNT(*) AS total_orders,
        COALESCE(SUM(total_amount), 0) AS total_revenue
    FROM orders
    WHERE status = 'paid'
")->fetch();

$games = $pdo->query("
    SELECT
        g.title,
        COALESCE(SUM(oi.quantity), 0) AS units_sold,
        COALESCE(SUM(oi.quantity * oi.price_at_purchase), 0) AS revenue
    FROM games g
    JOIN order_items oi ON oi.game_id = g.id
    JOIN orders o ON o.id = oi.order_id AND o.status = 'paid'
    GROUP BY g.id, g.title
    ORDER BY revenue DESC, g.title ASC
")->fetchAll();

$generatedAt = date('Y-m-d H:i:s');
$tempFile = tempnam($directory, '.report-');

if ($tempFile === false) {
    fwrite(STDERR, "Gagal membuat file sementara.\n");
    exit(1);
}

try {
    $fp = fopen($tempFile, 'wb');
    if ($fp === false) {
        throw new RuntimeException('Gagal membuka file sementara.');
    }

    // UTF-8 BOM membantu Excel mengenali encoding CSV.
    fwrite($fp, "\xEF\xBB\xBF");

    fputcsv($fp, [
        'jenis', 'waktu_dibuat', 'metrik', 'nilai',
        'game', 'unit_terjual', 'pendapatan'
    ], ',', '"', '');

    fputcsv($fp, [
        'ringkasan', $generatedAt, 'transaksi_paid',
        (string) $summary['total_orders'], '', '', ''
    ], ',', '"', '');

    fputcsv($fp, [
        'ringkasan', $generatedAt, 'pendapatan_total',
        (string) $summary['total_revenue'], '', '', ''
    ], ',', '"', '');

    foreach ($games as $game) {
        fputcsv($fp, [
            'game',
            $generatedAt,
            '',
            '',
            $game['title'],
            (string) $game['units_sold'],
            (string) $game['revenue']
        ], ',', '"', '');
    }

    if (!fclose($fp)) {
        throw new RuntimeException('Gagal menutup file CSV.');
    }

    chmod($tempFile, 0644);

    if (!rename($tempFile, $directory . '/marketplace-summary.csv')) {
        throw new RuntimeException('Gagal memperbarui file laporan.');
    }

    echo "Laporan diperbarui: {$generatedAt}\n";
} catch (Throwable $e) {
    if (is_file($tempFile)) {
        unlink($tempFile);
    }

    fwrite(STDERR, "Generator laporan gagal: " . $e->getMessage() . "\n");
    exit(1);
}
