<?php
use App\Services\Session;
$csrf = Session::csrfToken();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register | Andhika Games</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<main class="auth-container">
    <h1>Buat Akun</h1>
    <p>Daftar untuk mulai membangun koleksi game-mu.</p>

    <?php if (isset($error)): ?>
        <p role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
    <?php endif; ?>

    <form method="post" action="/register">
        <input type="hidden" name="csrf_token"
               value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">

        <label for="name">Nama</label>
        <input id="name" name="name" type="text" maxlength="100"
               autocomplete="name" required>

        <label for="email">Email</label>
        <input id="email" name="email" type="email" maxlength="190"
               autocomplete="email" required>

        <label for="password">Kata sandi (minimal 12 karakter)</label>
        <input id="password" name="password" type="password"
               minlength="12" autocomplete="new-password" required>

        <label for="password_confirmation">Ulangi kata sandi</label>
        <input id="password_confirmation" name="password_confirmation"
               type="password" minlength="12"
               autocomplete="new-password" required>

        <button type="submit">Daftar</button>
    </form>

    <p>Sudah punya akun? <a href="/login">Login</a></p>
    <p><a href="/">Kembali ke katalog</a></p>
</main>
</body>
</html>
