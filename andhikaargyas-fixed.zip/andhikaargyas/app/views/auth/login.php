<?php
use App\Services\Session;
$csrf = Session::csrfToken();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login | Andhika Games</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<main class="auth-container">
    <h1>Login</h1>
    <p>Masuk ke akun Andhika Games.</p>

    <?php if (isset($error)): ?>
        <p role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
    <?php endif; ?>

    <form method="post" action="/login">
        <input type="hidden" name="csrf_token"
               value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">

        <label for="email">Email</label>
        <input id="email" name="email" type="email"
               autocomplete="username" required>

        <label for="password">Kata sandi</label>
        <input id="password" name="password" type="password"
               autocomplete="current-password" required>

        <button type="submit">Masuk</button>
    </form>

    <p>Belum punya akun? <a href="/register">Daftar</a></p>
    <p><a href="/">Kembali ke katalog</a></p>
</main>
</body>
</html>
