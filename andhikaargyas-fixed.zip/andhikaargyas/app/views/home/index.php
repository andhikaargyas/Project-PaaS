<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Discover | Andhika Store</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<header class="navbar">
    <a class="brand" href="/">ANDHIKA<span>STORE</span></a>
    <nav>
        <a href="/">Discover</a>
        <a href="/login">Login</a>
        <a class="button button-email"
           href="http://mail.andhikaargyas.sh"
           target="_blank"
           rel="noopener noreferrer">✉ Email</a>
        <a class="button" href="/register">Join now</a>
    </nav>
</header>

<main class="container">
    <section class="hero">
        <p class="eyebrow">YOUR NEXT ADVENTURE STARTS HERE</p>
        <h1>Find your next<br><span>favorite game.</span></h1>
        <p class="subtitle">
            Explore new worlds, discover great games,
            and build your collection.
        </p>
    </section>

    <section class="catalog">
        <div class="section-heading">
            <div>
                <p class="eyebrow">THE COLLECTION</p>
                <h2>Featured games</h2>
            </div>
            <span><?= count($games) ?> games</span>
        </div>

        <div class="game-grid">
            <?php foreach ($games as $game): ?>
                <a class="game-card"
                   href="/game/<?= rawurlencode($game['slug']) ?>">
                    <div class="game-cover">
                        <span class="cover-label">
                            <?= htmlspecialchars(
                                $game['developer'] ?? 'Game',
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </span>
                        <h3><?= htmlspecialchars(
                            $game['title'],
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?></h3>
                    </div>

                    <div class="game-info">
                        <span><?= htmlspecialchars(
                            $game['title'],
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?></span>
                        <strong>Rp <?= number_format(
                            (float) $game['price'],
                            0,
                            ',',
                            '.'
                        ) ?></strong>
                    </div>
                </a>
            <?php endforeach; ?>

            <?php if (!$games): ?>
                <p>Belum ada game di katalog.</p>
            <?php endif; ?>
        </div>
    </section>
</main>

<footer>ANDHIKA STORE · GAME MARKETPLACE</footer>
</body>
</html>
