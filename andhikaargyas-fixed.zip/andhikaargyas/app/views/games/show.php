<?php
use App\Services\Session;

Session::start();

$loggedIn = !empty($_SESSION['user_id']);
$csrf = Session::csrfToken();

$escape = static fn ($value): string =>
    htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $escape($game['title']) ?> | Andhika Store</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<header class="navbar">
    <a class="brand" href="/">ANDHIKA<span>STORE</span></a>
    <nav>
        <a href="/">Discover</a>
        <?php if ($loggedIn): ?>
            <a href="/profile">Profil</a>
            <a href="/orders">Pesanan</a>
            <a href="/library">Library</a>
        <?php else: ?>
            <a href="/login">Login</a>
            <a class="button" href="/register">Join now</a>
        <?php endif; ?>
    </nav>
</header>

<main class="container">
    <p class="breadcrumb"><a href="/">Discover</a> / Game details</p>

    <section class="detail">
        <div class="detail-cover">
            <span class="eyebrow">GAME DETAILS</span>
            <h1><?= $escape($game['title']) ?></h1>
        </div>

        <div class="detail-info">
            <p class="eyebrow">ABOUT THIS GAME</p>
            <h2><?= $escape($game['title']) ?></h2>
            <p><?= nl2br($escape($game['description'] ?? '')) ?></p>

            <dl>
                <dt>Developer</dt>
                <dd><?= $escape($game['developer'] ?? 'Unknown') ?></dd>

                <dt>Release date</dt>
                <dd><?= $escape($game['release_date'] ?? 'Not specified') ?></dd>
            </dl>

            <div class="purchase">
                <strong>Rp <?= number_format(
                    (float) $game['price'], 0, ',', '.'
                ) ?></strong>

                <?php if ($loggedIn): ?>
                    <form action="/buy" method="post">
                        <input type="hidden" name="game_id"
                               value="<?= (int) $game['id'] ?>">
                        <input type="hidden" name="_csrf"
                               value="<?= $escape($_SESSION['order_csrf'] ?? '') ?>">
                        <input type="hidden" name="csrf_token"
                               value="<?= $escape($csrf) ?>">
                        <button class="button" type="submit">
                            Pesan sekarang
                        </button>
                    </form>
                <?php else: ?>
                    <a class="button" href="/login">Login untuk memesan</a>
                <?php endif; ?>
            </div>
        </div>
    </section>
</main>

<footer>ANDHIKA STORE · GAME MARKETPLACE</footer>
</body>
</html>
