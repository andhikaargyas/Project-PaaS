<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Game not found | Andhika Store</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<main class="container not-found">
    <p class="eyebrow">404 · NOT FOUND</p>
    <h1>Game not found.</h1>
    <p>Game ini tidak tersedia atau sudah tidak aktif.</p>
    <a class="button" href="/">Back to discover</a>
</main>
</body>
</html>
