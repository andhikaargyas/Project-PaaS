<?php
declare(strict_types=1);

function adminEscape(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$messages = [
    'created' => 'Game berhasil ditambahkan.',
    'updated' => 'Informasi game berhasil diperbarui.',
    'toggled' => 'Status game berhasil diubah.',
    'duplicate' => 'Slug game sudah digunakan.',
    'invalid' => 'Data tidak valid. Periksa kembali semua kolom.',
];
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Game - AndhikaArgyas</title>
    <link rel="stylesheet" href="/assets/style.css">
    <style>
        body{font-family:Arial,sans-serif;max-width:1200px;margin:30px auto;padding:0 18px}
        input,textarea{box-sizing:border-box;width:100%;padding:9px;margin:5px 0 12px}
        textarea{min-height:75px}
        .panel{border:1px solid #7775;border-radius:10px;padding:18px;margin:20px 0}
        .game{border-top:1px solid #7775;padding:18px 0}
        .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}
        button{padding:9px 15px;cursor:pointer}
        .notice{padding:12px;background:#d9f5df;color:#174d26;border-radius:6px}
        .inactive{opacity:.7}
    </style>
</head>
<body>
    <p><a href="/">← Marketplace</a> · <a href="/profile">Profil</a></p>
    <h1>Admin Dashboard</h1>
    <p>Ringkasan marketplace dan pengelolaan katalog game.</p>

    <section class="admin-stats">
        <article><span>Total pengguna</span><strong><?= (int) $stats['total_users'] ?></strong></article>
        <article><span>Total game</span><strong><?= (int) $stats['total_games'] ?></strong></article>
        <article><span>Game aktif</span><strong><?= (int) $stats['active_games'] ?></strong></article>
        <article><span>Total pesanan</span><strong><?= (int) $stats['total_orders'] ?></strong></article>
        <article><span>Menunggu pembayaran</span><strong><?= (int) $stats['pending_orders'] ?></strong></article>
        <article><span>Transaksi lunas</span><strong><?= (int) $stats['paid_orders'] ?></strong></article>
        <article><span>Pendapatan transaksi lunas</span><strong>Rp <?= number_format((float) $stats['revenue'], 0, ',', '.') ?></strong></article>
    </section>

    <section class="panel">
        <p style="margin: 12px 0;">
            <a href="/admin/transactions/export"
               style="display:inline-block;padding:10px 16px;background:#198754;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;">
                Unduh Riwayat Transaksi (Excel)
            </a>
        </p>
        <h2>Transaksi terbaru</h2>
        <?php if (!$recentOrders): ?>
            <p>Belum ada transaksi.</p>
        <?php else: ?>
        <div class="table-wrap"><table class="dash-table">
            <thead><tr><th>ID</th><th>Pengguna</th><th>Total</th><th>Status</th><th>Tanggal</th></tr></thead>
            <tbody><?php foreach ($recentOrders as $order): ?>
                <tr>
                    <td>#<?= (int) $order['id'] ?></td>
                    <td><?= adminEscape($order['name']) ?><br><small><?= adminEscape($order['email']) ?></small></td>
                    <td>Rp <?= number_format((float) $order['total_amount'], 0, ',', '.') ?></td>
                    <td><?= adminEscape($order['status']) ?></td>
                    <td><?= adminEscape($order['created_at']) ?></td>
                </tr>
            <?php endforeach; ?></tbody>
        </table></div>
        <?php endif; ?>
    </section>

    <?php if (isset($messages[$status])): ?>
        <p class="notice"><?= adminEscape($messages[$status]) ?></p>
    <?php endif; ?>

    <section class="panel">
        <h2>Tambah game</h2>
        <form action="/admin/games/create" method="post">
            <input type="hidden" name="_csrf" value="<?= adminEscape($csrf) ?>">
            <div class="grid">
                <label>Judul
                    <input name="title" maxlength="200" required>
                </label>
                <label>Slug URL (contoh: minecraft)
                    <input name="slug" pattern="[a-z0-9]+(-[a-z0-9]+)*" maxlength="150" required>
                </label>
                <label>Harga (Rupiah)
                    <input name="price" type="number" min="0" step="0.01" required>
                </label>
                <label>Developer
                    <input name="developer" maxlength="150">
                </label>
                <label>Tanggal rilis
                    <input name="release_date" type="date">
                </label>
            </div>
            <label>Deskripsi
                <textarea name="description" required></textarea>
            </label>
            <button type="submit">Tambah game</button>
        </form>
    </section>

    <section class="panel">
        <h2>Daftar game (<?= count($games) ?>)</h2>

        <?php foreach ($games as $game): ?>
            <article class="game <?= empty($game['is_active']) ? 'inactive' : '' ?>">
                <h3>
                    <?= adminEscape($game['title']) ?>
                    <?= empty($game['is_active']) ? '(Nonaktif)' : '(Aktif)' ?>
                </h3>

                <form action="/admin/games/update" method="post">
                    <input type="hidden" name="_csrf" value="<?= adminEscape($csrf) ?>">
                    <input type="hidden" name="id" value="<?= (int) $game['id'] ?>">

                    <div class="grid">
                        <label>Judul
                            <input name="title" maxlength="200" value="<?= adminEscape($game['title']) ?>" required>
                        </label>
                        <label>Slug
                            <input name="slug" pattern="[a-z0-9]+(-[a-z0-9]+)*" maxlength="150" value="<?= adminEscape($game['slug']) ?>" required>
                        </label>
                        <label>Harga (Rupiah)
                            <input name="price" type="number" min="0" step="0.01" value="<?= adminEscape($game['price']) ?>" required>
                        </label>
                        <label>Developer
                            <input name="developer" maxlength="150" value="<?= adminEscape($game['developer'] ?? '') ?>">
                        </label>
                        <label>Tanggal rilis
                            <input name="release_date" type="date" value="<?= adminEscape($game['release_date'] ?? '') ?>">
                        </label>
                    </div>

                    <label>Deskripsi
                        <textarea name="description" required><?= adminEscape($game['description']) ?></textarea>
                    </label>
                    <button type="submit">Simpan perubahan</button>
                </form>

                <form action="/admin/games/toggle" method="post">
                    <input type="hidden" name="_csrf" value="<?= adminEscape($csrf) ?>">
                    <input type="hidden" name="id" value="<?= (int) $game['id'] ?>">
                    <button type="submit">
                        <?= empty($game['is_active']) ? 'Aktifkan game' : 'Nonaktifkan game' ?>
                    </button>
                </form>
            </article>
        <?php endforeach; ?>
    </section>
</body>
</html>
