<?php
$escape = static fn($value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
$money = static fn($value): string => 'Rp ' . number_format((float) $value, 0, ',', '.');
$labels = ['pending'=>'Menunggu pembayaran','paid'=>'Lunas','cancelled'=>'Dibatalkan','refunded'=>'Dikembalikan'];
$csrf = \App\Services\Session::csrfToken();
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Transaksi Saya | Andhika Games</title><link rel="stylesheet" href="/assets/style.css">
</head>
<body class="dashboard-body">
<header class="dash-topbar"><a class="dash-brand" href="/">ANDHIKA<span> GAMES</span></a>
<nav class="dash-nav"><a href="/">Marketplace</a><a href="/profile">Dashboard</a><a href="/library">Library</a></nav></header>
<main class="dash-container">
<section class="page-heading"><p class="eyebrow">AKUN KAMU</p><h1>Riwayat transaksi</h1><p class="muted">Semua pesanan yang terhubung dengan akunmu.</p></section>
<section class="dash-panel">
<?php if (($_GET['payment'] ?? '') === 'success'): ?>
<p class="status-chip status-paid">Simulasi berhasil: status pesanan berubah menjadi Lunas.</p>
<?php elseif (($_GET['payment'] ?? '') === 'unchanged'): ?>
<p class="muted">Pesanan tidak ditemukan, bukan milik akunmu, atau statusnya bukan Menunggu pembayaran.</p>
<?php elseif (($_GET['payment'] ?? '') === 'invalid'): ?>
<p class="muted">ID pesanan tidak valid.</p>
<?php endif; ?>

<?php if (!$orders): ?>
<div class="empty-state"><span>🧾</span><h2>Belum ada pesanan</h2><p>Pesanan game kamu akan muncul di halaman ini.</p><a class="btn btn-primary" href="/">Lihat katalog</a></div>
<?php else: ?>
<div class="table-wrap"><table class="dash-table">
<thead><tr><th>Pesanan</th><th>Item</th><th>Total</th><th>Status</th><th>Tanggal</th><th>Aksi</th></tr></thead>
<tbody><?php foreach ($orders as $order): ?>
<tr><td>#<?= (int)$order['id'] ?></td><td><?= $escape($order['items'] ?? '') ?></td>
<td><?= $money($order['total_amount']) ?></td>
<td><span class="status-chip status-<?= $escape($order['status']) ?>"><?= $escape($labels[$order['status']] ?? $order['status']) ?></span></td>
<td><?= $escape($order['created_at']) ?></td>
<td>
<?php if ($order['status'] === 'pending'): ?>
<form action="/simulate-payment" method="post">
<input type="hidden" name="order_id" value="<?= (int)$order['id'] ?>">
<input type="hidden" name="csrf_token" value="<?= $escape($csrf) ?>">
<button class="btn btn-primary" type="submit">Bayar Sekarang</button>
</form>
<?php else: ?>
<span class="muted">—</span>
<?php endif; ?>
</td></tr>
<?php endforeach; ?></tbody></table></div>
<?php endif; ?>
</section></main></body></html>
