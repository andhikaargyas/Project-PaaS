<?php
use App\Services\Session;

$csrf = Session::csrfToken();
$escape = static fn($value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
$initial = mb_strtoupper(mb_substr((string) $user['name'], 0, 1));
$money = static fn($value): string => 'Rp ' . number_format((float) $value, 0, ',', '.');
$statusLabels = [
    'pending' => 'Menunggu pembayaran',
    'paid' => 'Lunas',
    'cancelled' => 'Dibatalkan',
    'refunded' => 'Dikembalikan',
];
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Akun | Andhika Games</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body class="dashboard-body">
<header class="dash-topbar">
    <a class="dash-brand" href="/">ANDHIKA<span> GAMES</span></a>
    <nav class="dash-nav">
        <a href="/">Marketplace</a>
        <a href="/library">Library</a>
        <a href="/orders">Transaksi</a>
        <?php if (($user['role'] ?? '') === 'admin'): ?>
            <a href="/admin">Admin</a>
        <?php endif; ?>
    </nav>
</header>

<main class="dash-container">
    <section class="profile-hero">
        <div class="profile-identity">
            <div class="profile-avatar"><?= $escape($initial) ?></div>
            <div>
                <p class="eyebrow">DASHBOARD AKUN</p>
                <h1>Halo, <?= $escape($user['name']) ?>!</h1>
                <p class="muted"><?= $escape($user['email']) ?></p>
                <span class="role-chip"><?= $escape(strtoupper($user['role'])) ?></span>
            </div>
        </div>
        <div class="profile-actions">
            <a class="btn btn-primary" href="/">Jelajahi game</a>
            <form method="post" action="/logout">
                <input type="hidden" name="csrf_token" value="<?= $escape($csrf) ?>">
                <button class="btn btn-outline" type="submit">Logout</button>
            </form>
        </div>
    </section>

    <section class="stats-grid" aria-label="Ringkasan akun">
        <article class="stat-card">
            <span class="stat-icon">🎮</span>
            <p>Game dimiliki</p>
            <strong><?= (int) $stats['owned_games'] ?></strong>
            <a href="/library">Lihat library →</a>
        </article>
        <article class="stat-card">
            <span class="stat-icon">🧾</span>
            <p>Total pesanan</p>
            <strong><?= (int) $stats['total_orders'] ?></strong>
            <a href="/orders">Lihat transaksi →</a>
        </article>
        <article class="stat-card">
            <span class="stat-icon">⌛</span>
            <p>Menunggu pembayaran</p>
            <strong><?= (int) $stats['pending_orders'] ?></strong>
            <span class="muted">Pesanan belum lunas</span>
        </article>
        <article class="stat-card">
            <span class="stat-icon">💳</span>
            <p>Total belanja lunas</p>
            <strong class="stat-money"><?= $money($stats['total_spent']) ?></strong>
            <span class="muted"><?= (int) $stats['paid_orders'] ?> transaksi lunas</span>
        </article>
    </section>

    <section class="dash-panel">
        <div class="section-heading">
            <div><p class="eyebrow">AKTIVITAS</p><h2>Transaksi terbaru</h2></div>
            <a href="/orders">Lihat semua →</a>
        </div>
        <?php if (!$recentOrders): ?>
            <div class="empty-state">
                <span>🕹️</span>
                <h3>Belum ada transaksi</h3>
                <p>Game yang kamu beli akan tercatat di sini.</p>
                <a class="btn btn-primary" href="/">Jelajahi katalog</a>
            </div>
        <?php else: ?>
            <div class="table-wrap">
                <table class="dash-table">
                    <thead><tr><th>Pesanan</th><th>Item</th><th>Total</th><th>Status</th><th>Tanggal</th></tr></thead>
                    <tbody>
                    <?php foreach ($recentOrders as $order): ?>
                        <tr>
                            <td>#<?= (int) $order['id'] ?></td>
                            <td><?= $escape($order['items'] ?? 'Item') ?></td>
                            <td><?= $money($order['total_amount']) ?></td>
                            <td><span class="status-chip status-<?= $escape($order['status']) ?>"><?= $escape($statusLabels[$order['status']] ?? $order['status']) ?></span></td>
                            <td><?= $escape($order['created_at']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>

    <footer class="dash-footer">
        <span>Terdaftar sejak <?= $escape($user['created_at']) ?></span>
        <span>Andhika Games · Player Dashboard</span>
    </footer>
</main>
</body>
</html>
