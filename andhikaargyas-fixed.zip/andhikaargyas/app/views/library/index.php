<?php
$escape = static fn($value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
?>
<!doctype html>
<html lang="id">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Library Game | Andhika Games</title><link rel="stylesheet" href="/assets/style.css"></head>
<body class="dashboard-body">
<header class="dash-topbar"><a class="dash-brand" href="/">ANDHIKA<span> GAMES</span></a>
<nav class="dash-nav"><a href="/">Marketplace</a><a href="/profile">Dashboard</a><a href="/orders">Transaksi</a></nav></header>
<main class="dash-container"><section class="page-heading"><p class="eyebrow">KOLEKSI KAMU</p><h1>Library game</h1>
<p class="muted">Hanya game dari pesanan berstatus lunas yang tampil di sini.</p></section>
<?php if (!$games): ?>
<section class="dash-panel empty-state"><span>🎮</span><h2>Library masih kosong</h2><p>Game yang sudah dibayar akan muncul di sini.</p><a class="btn btn-primary" href="/">Temukan game</a></section>
<?php else: ?>
<section class="game-library-grid">
<?php foreach ($games as $game): ?>
<article class="library-card">
<div class="library-art"><?php if (!empty($game['image_url'])): ?>
<img src="<?= $escape($game['image_url']) ?>" alt="<?= $escape($game['title']) ?>" loading="lazy">
<?php else: ?><span>🎮</span><?php endif; ?></div>
<div class="library-card-body"><span class="owned-chip">✓ DIMILIKI</span><h2><?= $escape($game['title']) ?></h2>
<p class="muted"><?= $escape($game['developer'] ?? 'Developer tidak tersedia') ?></p>
<a class="btn btn-primary" href="/game/<?= rawurlencode($game['slug']) ?>">Lihat game</a></div>
</article>
<?php endforeach; ?>
</section>
<?php endif; ?></main></body></html>
