<?php
declare(strict_types=1);

use App\Controllers\AdminController;
use App\Controllers\AuthController;
use App\Controllers\GameController;
use App\Controllers\HomeController;
use App\Controllers\OrderController;

return [
    ['GET',  '~^/$~',                         [HomeController::class, 'index']],
    ['GET',  '~^/login$~',                    [AuthController::class, 'login']],
    ['POST', '~^/login$~',                    [AuthController::class, 'login']],
    ['GET',  '~^/register$~',                 [AuthController::class, 'register']],
    ['POST', '~^/register$~',                 [AuthController::class, 'register']],
    ['POST', '~^/logout$~',                   [AuthController::class, 'logout']],
    ['GET',  '~^/profile$~',                  [AuthController::class, 'profile']],
    ['GET',  '~^/game/([a-z0-9-]+)$~',        [GameController::class, 'show']],

    ['POST', '~^/buy$~',                    [OrderController::class, 'buy']],
    ['POST', '~^/simulate-payment$~', [OrderController::class, 'simulatePayment']],
    ['GET',  '~^/orders$~',                 [OrderController::class, 'index']],
    ['GET',  '~^/library$~',                [OrderController::class, 'library']],
    ['GET',  '~^/admin/transactions/export$~', [AdminController::class, 'exportTransactions']],
    ['GET',  '~^/admin$~',                    [AdminController::class, 'index']],
    ['POST', '~^/admin/games/create$~',       [AdminController::class, 'create']],
    ['POST', '~^/admin/games/update$~',       [AdminController::class, 'update']],
    ['POST', '~^/admin/games/toggle$~',       [AdminController::class, 'toggle']],
];
