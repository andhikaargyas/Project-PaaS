<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/vendor/autoload.php';

use App\Models\Database;

function rejectAccess(): never
{
    header('WWW-Authenticate: Basic realm="Laporan Marketplace", charset="UTF-8"');
    header('Cache-Control: no-store');
    http_response_code(401);
    exit('401 Unauthorized: autentikasi diperlukan untuk laporan.');
}

$username = '';
$password = '';
$authorization = $_SERVER['HTTP_AUTHORIZATION']
    ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
    ?? '';

if (stripos($authorization, 'Basic ') === 0) {
    $decoded = base64_decode(substr($authorization, 6), true);

    if ($decoded !== false && str_contains($decoded, ':')) {
        [$username, $password] = explode(':', $decoded, 2);
    }
}

$allowedUsers = [
    'karyawan' => getenv('REPORT_PASSWORD_KARYAWAN') ?: '',
    'pengelola' => getenv('REPORT_PASSWORD_PENGELOLA') ?: '',
];

$expectedPassword = $allowedUsers[$username] ?? '';

if (
    $expectedPassword === ''
    || $password === ''
    || !hash_equals($expectedPassword, $password)
) {
    rejectAccess();
}

header('Cache-Control: no-store');

$pdo = Database::connection();

$summary = $pdo->query("
    SELECT
        COUNT(*) AS total_orders,
        COALESCE(SUM(total_amount), 0) AS total_revenue
    FROM orders
    WHERE status = 'paid'
")->fetch();

$games = $pdo->query("
    SELECT
        g.title,
        COALESCE(SUM(oi.quantity), 0) AS units_sold,
        COALESCE(SUM(oi.quantity * oi.price_at_purchase), 0) AS revenue
    FROM games g
    JOIN order_items oi ON oi.game_id = g.id
    JOIN orders o ON o.id = oi.order_id AND o.status = 'paid'
    GROUP BY g.id, g.title
    ORDER BY revenue DESC, g.title ASC
")->fetchAll();

function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function rupiah(mixed $value): string
{
    return 'Rp ' . number_format((float) $value, 0, ',', '.');
}
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>Laporan Penjualan - AndhikaArgyas</title>
    <style>
        body{font-family:Arial,sans-serif;background:#10131c;color:#f2f4fa;margin:0;padding:28px}
        main{max-width:1100px;margin:auto}
        .cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px}
        .card,section{background:#1b2130;padding:20px;border-radius:12px;margin:16px 0}
        .value{font-size:28px;font-weight:bold;margin-top:12px}
        table{width:100%;border-collapse:collapse}
        th,td{text-align:left;padding:12px;border-bottom:1px solid #353d50}
        .table-wrap{overflow-x:auto}
        .muted{color:#b8c0d4}
    </style>
</head>
<body>
<main>
    <h1>Laporan Penjualan Marketplace</h1>
    <p>Pengguna: <?= e($username) ?></p>
    <p class="muted">Ringkasan langsung dari database. Hanya transaksi berstatus paid yang dihitung.</p>

    <div class="cards">
        <div class="card">
            <div>Total transaksi berhasil</div>
            <div class="value"><?= number_format((int) $summary['total_orders']) ?></div>
        </div>
        <div class="card">
            <div>Total pendapatan</div>
            <div class="value"><?= e(rupiah($summary['total_revenue'])) ?></div>
        </div>
    </div>

    <section>
        <h2>Penjualan per game</h2>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr><th>Game</th><th>Unit terjual</th><th>Pendapatan</th></tr>
                </thead>
                <tbody>
                <?php if (!$games): ?>
                    <tr><td colspan="3">Belum ada penjualan game berstatus paid.</td></tr>
                <?php else: foreach ($games as $game): ?>
                    <tr>
                        <td><?= e($game['title']) ?></td>
                        <td><?= number_format((int) $game['units_sold']) ?></td>
                        <td><?= e(rupiah($game['revenue'])) ?></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <p class="muted">CSV untuk diunduh tersedia melalui folder Reports pada FTP atau Samba.</p>
    <p class="muted">Data diperbarui saat halaman dimuat ulang.</p>
</main>
</body>
</html>
