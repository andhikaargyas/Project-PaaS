<?php
declare(strict_types=1);

require dirname(__DIR__) . '/vendor/autoload.php';

\App\Services\Session::start();

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$routes = require dirname(__DIR__) . '/routes/web.php';

foreach ($routes as [$allowedMethod, $pattern, $handler]) {
    if ($method !== $allowedMethod) {
        continue;
    }

    if (preg_match($pattern, $path, $matches)) {
        array_shift($matches);

        if (
            is_array($handler) &&
            count($handler) === 2 &&
            is_string($handler[0])
        ) {
            $controllerClass = $handler[0];
            $controllerMethod = $handler[1];

            $controller = new $controllerClass();
            $callback = [$controller, $controllerMethod];
        } else {
            $callback = $handler;
        }

        if (!is_callable($callback)) {
            http_response_code(500);
            error_log('Invalid route callback for path: ' . $path);
            echo '500 Internal Server Error';
            exit;
        }

        call_user_func_array($callback, $matches);
        exit;
    }
}

http_response_code(404);
echo '404 Not Found';
