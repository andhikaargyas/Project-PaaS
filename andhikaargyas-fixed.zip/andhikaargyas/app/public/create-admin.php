<?php
$pdo = new PDO(
    'mysql:host=db;dbname=marketplace;charset=utf8mb4',
    getenv('DB_USER') ?: 'marketplace_app',
    getenv('DB_PASSWORD'),
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
);

$email = 'admin@andhikaargyas.sh';
$password = 'admin123';

$stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
$stmt->execute([$email]);
$id = $stmt->fetchColumn();

if ($id) {
    $stmt = $pdo->prepare("UPDATE users SET role = 'admin' WHERE id = ?");
    $stmt->execute([$id]);
    echo "Admin sudah ada; role dipastikan admin.\n";
} else {
    $stmt = $pdo->prepare(
        'INSERT INTO users (name, email, password_hash, role)
         VALUES (?, ?, ?, ?)'
    );
    $stmt->execute([
        'admin',
        $email,
        password_hash($password, PASSWORD_DEFAULT),
        'admin'
    ]);
    echo "Akun admin berhasil dibuat.\n";
}
