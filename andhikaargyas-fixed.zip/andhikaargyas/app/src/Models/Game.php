<?php

declare(strict_types=1);

namespace App\Models;

use PDO;

final class Game
{
    public static function allActive(): array
    {
        $sql = '
            SELECT id, slug, title, description, price,
                   image_url, developer, release_date
            FROM games
            WHERE is_active = 1
            ORDER BY title ASC
        ';

        return Database::connection()
            ->query($sql)
            ->fetchAll();
    }

    public static function findBySlug(string $slug): ?array
    {
        $sql = '
            SELECT id, slug, title, description, price,
                   image_url, developer, release_date
            FROM games
            WHERE slug = :slug
              AND is_active = 1
            LIMIT 1
        ';

        $statement = Database::connection()->prepare($sql);
        $statement->execute(['slug' => $slug]);

        $game = $statement->fetch();

        return $game ?: null;
    }
}
