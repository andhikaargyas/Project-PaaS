<?php
declare(strict_types=1);

namespace App\Middleware;

use App\Models\User;
use App\Services\Session;

final class AuthMiddleware
{
    public static function requireLogin(): array
    {
        Session::start();
        $id = $_SESSION['user_id'] ?? null;

        if (!is_int($id) || $id < 1) {
            header('Location: /login', true, 303);
            exit;
        }

        $user = User::findById($id);

        if ($user === null) {
            $_SESSION = [];
            session_regenerate_id(true);
            header('Location: /login', true, 303);
            exit;
        }

        return $user;
    }

    public static function requireAdmin(): array
    {
        $user = self::requireLogin();

        if ($user['role'] !== 'admin') {
            http_response_code(403);
            exit('403 Forbidden');
        }

        return $user;
    }
}
