<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\Database;
use App\Models\User;

final class AdminController
{
    private static function authorize(): bool
    {
        if (empty($_SESSION['user_id'])) {
            header('Location: /login');
            return false;
        }

        $user = User::findById((int) $_SESSION['user_id']);

        if (!$user || $user['role'] !== 'admin') {
            http_response_code(403);
            echo '403 Forbidden: akses khusus admin.';
            return false;
        }

        return true;
    }

    private static function csrfToken(): string
    {
        if (empty($_SESSION['admin_csrf'])) {
            $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
        }

        return $_SESSION['admin_csrf'];
    }

    private static function verifyPost(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            exit('Method Not Allowed');
        }

        $submitted = (string) ($_POST['_csrf'] ?? '');
        $expected = (string) ($_SESSION['admin_csrf'] ?? '');

        if ($expected === '' || !hash_equals($expected, $submitted)) {
            http_response_code(419);
            exit('Token keamanan tidak valid. Muat ulang halaman.');
        }
    }

    private static function redirect(string $status): never
    {
        header('Location: /admin?status=' . rawurlencode($status));
        exit;
    }

    public static function index(): void
    {
        if (!self::authorize()) {
            return;
        }

        $pdo = Database::connection();

        $games = $pdo->query('SELECT * FROM games ORDER BY id DESC')->fetchAll();

        $stats = $pdo->query(
            "SELECT
                (SELECT COUNT(*) FROM users) AS total_users,
                (SELECT COUNT(*) FROM games) AS total_games,
                (SELECT COUNT(*) FROM games WHERE is_active = 1) AS active_games,
                (SELECT COUNT(*) FROM orders) AS total_orders,
                (SELECT COUNT(*) FROM orders WHERE status = 'pending') AS pending_orders,
                (SELECT COUNT(*) FROM orders WHERE status = 'paid') AS paid_orders,
                (SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE status = 'paid') AS revenue"
        )->fetch();

        $recentOrders = $pdo->query(
            "SELECT o.id, o.status, o.total_amount, o.created_at, u.name, u.email
             FROM orders o
             JOIN users u ON u.id = o.user_id
             ORDER BY o.id DESC LIMIT 8"
        )->fetchAll();

        $csrf = self::csrfToken();
        $status = (string) ($_GET['status'] ?? '');

        require dirname(__DIR__, 2) . '/views/admin/index.php';
    }


    public static function exportTransactions(): void
    {
        if (!self::authorize()) {
            return;
        }

        $pdo = Database::connection();

        $stats = $pdo->query(
            "SELECT
                (SELECT COUNT(*) FROM users) AS total_users,
                (SELECT COUNT(*) FROM games) AS total_games,
                (SELECT COUNT(*) FROM games WHERE is_active = 1) AS active_games,
                (SELECT COUNT(*) FROM orders) AS total_orders,
                (SELECT COUNT(*) FROM orders WHERE status = 'pending') AS pending_orders,
                (SELECT COUNT(*) FROM orders WHERE status = 'paid') AS paid_orders,
                (SELECT COALESCE(SUM(total_amount), 0)
                    FROM orders WHERE status = 'paid') AS revenue"
        )->fetch(\PDO::FETCH_ASSOC);

        $transactions = $pdo->query(
            "SELECT
                o.id AS order_id,
                o.created_at,
                o.paid_at,
                u.name AS buyer_name,
                u.email AS buyer_email,
                o.status,
                o.total_amount,
                g.title AS game_title,
                oi.quantity,
                oi.price_at_purchase
             FROM orders o
             JOIN users u ON u.id = o.user_id
             LEFT JOIN order_items oi ON oi.order_id = o.id
             LEFT JOIN games g ON g.id = oi.game_id
             ORDER BY o.id DESC, oi.id ASC"
        )->fetchAll(\PDO::FETCH_ASSOC);

        // Mencegah teks dari database diperlakukan sebagai formula oleh Excel.
        $safeText = static function ($value): string {
            $value = (string) ($value ?? '');
            if (preg_match('/^\s*[=+\-@]/u', $value)) {
                return "'" . $value;
            }
            return $value;
        };

        $filename = 'riwayat-transaksi-' . date('Y-m-d') . '.csv';

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: no-store, no-cache, must-revalidate');

        $out = fopen('php://output', 'w');
        if ($out === false) {
            http_response_code(500);
            exit('Gagal membuat file ekspor.');
        }

        // BOM membantu Excel membaca karakter UTF-8.
        fwrite($out, "\xEF\xBB\xBF");

        fputcsv($out, ['RINGKASAN MARKETPLACE']);
        fputcsv($out, ['Metrik', 'Nilai']);
        fputcsv($out, ['Total pengguna', $stats['total_users']]);
        fputcsv($out, ['Total game', $stats['total_games']]);
        fputcsv($out, ['Game aktif', $stats['active_games']]);
        fputcsv($out, ['Total pesanan', $stats['total_orders']]);
        fputcsv($out, ['Menunggu pembayaran', $stats['pending_orders']]);
        fputcsv($out, ['Transaksi lunas', $stats['paid_orders']]);
        fputcsv($out, ['Pendapatan transaksi lunas (Rp)', $stats['revenue']]);
        fputcsv($out, []);
        fputcsv($out, ['RIWAYAT SELURUH TRANSAKSI']);

        fputcsv($out, [
            'ID Transaksi',
            'Tanggal Transaksi',
            'Tanggal Pembayaran',
            'Nama Pembeli',
            'Email Pembeli',
            'Status',
            'Total Transaksi (Rp)',
            'Nama Game',
            'Jumlah',
            'Harga per Item (Rp)',
        ]);

        foreach ($transactions as $row) {
            fputcsv($out, [
                $row['order_id'],
                $row['created_at'],
                $row['paid_at'],
                $safeText($row['buyer_name']),
                $safeText($row['buyer_email']),
                $safeText($row['status']),
                $row['total_amount'],
                $safeText($row['game_title']),
                $row['quantity'],
                $row['price_at_purchase'],
            ]);
        }

        fclose($out);
        exit;
    }

    public static function create(): void
    {
        if (!self::authorize()) {
            return;
        }

        self::verifyPost();

        $title = trim((string) ($_POST['title'] ?? ''));
        $slug = trim((string) ($_POST['slug'] ?? ''));
        $description = trim((string) ($_POST['description'] ?? ''));
        $price = filter_var($_POST['price'] ?? null, FILTER_VALIDATE_FLOAT);
        $developer = trim((string) ($_POST['developer'] ?? ''));
        $releaseDate = trim((string) ($_POST['release_date'] ?? ''));

        if (
            $title === '' || mb_strlen($title) > 200 ||
            !preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $slug) ||
            strlen($slug) > 150 ||
            $description === '' ||
            $price === false || $price < 0 || $price > 9999999999.99 ||
            mb_strlen($developer) > 150
        ) {
            self::redirect('invalid');
        }

        if ($releaseDate !== '') {
            $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $releaseDate);
            if (!$date || $date->format('Y-m-d') !== $releaseDate) {
                self::redirect('invalid');
            }
        } else {
            $releaseDate = null;
        }

        try {
            $stmt = Database::connection()->prepare(
                'INSERT INTO games
                    (slug, title, description, price, developer, release_date, is_active)
                 VALUES
                    (:slug, :title, :description, :price, :developer, :release_date, 1)'
            );

            $stmt->execute([
                'slug' => $slug,
                'title' => $title,
                'description' => $description,
                'price' => $price,
                'developer' => $developer !== '' ? $developer : null,
                'release_date' => $releaseDate,
            ]);
        } catch (\PDOException $e) {
            if ($e->getCode() === '23000') {
                self::redirect('duplicate');
            }
            throw $e;
        }

        self::redirect('created');
    }

    public static function update(): void
    {
        if (!self::authorize()) {
            return;
        }

        self::verifyPost();

        $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
        $title = trim((string) ($_POST['title'] ?? ''));
        $slug = trim((string) ($_POST['slug'] ?? ''));
        $description = trim((string) ($_POST['description'] ?? ''));
        $price = filter_var($_POST['price'] ?? null, FILTER_VALIDATE_FLOAT);
        $developer = trim((string) ($_POST['developer'] ?? ''));
        $releaseDate = trim((string) ($_POST['release_date'] ?? ''));

        if (
            !$id || $title === '' || mb_strlen($title) > 200 ||
            !preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $slug) ||
            strlen($slug) > 150 ||
            $description === '' ||
            $price === false || $price < 0 || $price > 9999999999.99 ||
            mb_strlen($developer) > 150
        ) {
            self::redirect('invalid');
        }

        if ($releaseDate !== '') {
            $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $releaseDate);
            if (!$date || $date->format('Y-m-d') !== $releaseDate) {
                self::redirect('invalid');
            }
        } else {
            $releaseDate = null;
        }

        try {
            $stmt = Database::connection()->prepare(
                'UPDATE games
                 SET slug = :slug, title = :title, description = :description,
                     price = :price, developer = :developer, release_date = :release_date
                 WHERE id = :id'
            );

            $stmt->execute([
                'slug' => $slug,
                'title' => $title,
                'description' => $description,
                'price' => $price,
                'developer' => $developer !== '' ? $developer : null,
                'release_date' => $releaseDate,
                'id' => $id,
            ]);
        } catch (\PDOException $e) {
            if ($e->getCode() === '23000') {
                self::redirect('duplicate');
            }
            throw $e;
        }

        self::redirect('updated');
    }

    public static function toggle(): void
    {
        if (!self::authorize()) {
            return;
        }

        self::verifyPost();

        $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);

        if (!$id) {
            self::redirect('invalid');
        }

        $stmt = Database::connection()->prepare(
            'UPDATE games SET is_active = NOT is_active WHERE id = :id'
        );
        $stmt->execute(['id' => $id]);

        self::redirect('toggled');
    }
}
