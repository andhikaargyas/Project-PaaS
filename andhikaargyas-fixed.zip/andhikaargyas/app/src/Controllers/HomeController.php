<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\Game;

final class HomeController
{
    public function index(): void
    {
        $games = Game::allActive();

        require __DIR__ . '/../../views/home/index.php';
    }
}
