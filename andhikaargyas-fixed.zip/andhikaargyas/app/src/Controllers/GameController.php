<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\Game;

final class GameController
{
    public function show(string $slug): void
    {
        $game = Game::findBySlug($slug);

        if ($game === null) {
            http_response_code(404);
            require __DIR__ . '/../../views/games/404.php';
            return;
        }

        require __DIR__ . '/../../views/games/show.php';
    }
}
