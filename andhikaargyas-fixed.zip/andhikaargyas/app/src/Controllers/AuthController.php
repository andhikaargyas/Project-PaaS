<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Middleware\AuthMiddleware;
use App\Models\User;
use App\Services\Session;
use PDOException;

final class AuthController
{
    public function register(): void
    {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
            require __DIR__ . '/../../views/auth/register.php';
            return;
        }

        if (!Session::verifyCsrf($_POST['csrf_token'] ?? null)) {
            http_response_code(419);
            exit('Form kedaluwarsa. Silakan muat ulang halaman.');
        }

        $name = trim((string) ($_POST['name'] ?? ''));
        $email = mb_strtolower(trim((string) ($_POST['email'] ?? '')));
        $password = (string) ($_POST['password'] ?? '');
        $confirmation = (string) ($_POST['password_confirmation'] ?? '');

        if (
            $name === '' ||
            mb_strlen($name) > 100 ||
            !filter_var($email, FILTER_VALIDATE_EMAIL) ||
            strlen($email) > 190 ||
            strlen($password) < 12 ||
            $password !== $confirmation
        ) {
            http_response_code(422);
            $error = 'Periksa nama, email, dan kata sandi. Kata sandi minimal 12 karakter dan kedua kolom harus cocok.';
            require __DIR__ . '/../../views/auth/register.php';
            return;
        }

        try {
            $id = User::create($name, $email, $password);
        } catch (PDOException $exception) {
            if ($exception->getCode() === '23000') {
                http_response_code(422);
                $error = 'Email tidak dapat digunakan. Periksa email yang dimasukkan.';
                require __DIR__ . '/../../views/auth/register.php';
                return;
            }

            throw $exception;
        }

        Session::start();
        session_regenerate_id(true);
        $_SESSION['user_id'] = $id;
        unset($_SESSION['csrf_token']);
        session_write_close();

        header('Location: /profile', true, 303);
        exit;
    }

    public function login(): void
    {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
            require __DIR__ . '/../../views/auth/login.php';
            return;
        }

        if (!Session::verifyCsrf($_POST['csrf_token'] ?? null)) {
            http_response_code(419);
            exit('Form kedaluwarsa. Silakan muat ulang halaman.');
        }

        $email = mb_strtolower(trim((string) ($_POST['email'] ?? '')));
        $password = (string) ($_POST['password'] ?? '');
        $user = User::findByEmail($email);

        if (
            $user === null ||
            !password_verify($password, $user['password_hash'])
        ) {
            http_response_code(401);
            $error = 'Email atau kata sandi salah.';
            require __DIR__ . '/../../views/auth/login.php';
            return;
        }

        Session::start();
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int) $user['id'];
        unset($_SESSION['csrf_token']);
        session_write_close();

        header('Location: /profile', true, 303);
        exit;
    }

    public function logout(): void
    {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            http_response_code(405);
            header('Allow: POST');
            exit('405 Method Not Allowed');
        }

        if (!Session::verifyCsrf($_POST['csrf_token'] ?? null)) {
            http_response_code(419);
            exit('Form kedaluwarsa. Silakan muat ulang halaman.');
        }

        Session::start();
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires' => time() - 42000,
                'path' => $params['path'],
                'domain' => $params['domain'],
                'secure' => $params['secure'],
                'httponly' => $params['httponly'],
                'samesite' => $params['samesite'] ?? 'Lax',
            ]);
        }

        session_destroy();
        header('Location: /', true, 303);
        exit;
    }

    public function profile(): void
    {
        $user = AuthMiddleware::requireLogin();
        $pdo = \App\Models\Database::connection();
        $userId = (int) $user['id'];

        $stmt = $pdo->prepare(
            "SELECT COUNT(*) AS total_orders,
                    COALESCE(SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END), 0) AS paid_orders,
                    COALESCE(SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END), 0) AS pending_orders,
                    COALESCE(SUM(CASE WHEN status = 'paid' THEN total_amount ELSE 0 END), 0) AS total_spent
             FROM orders WHERE user_id = ?"
        );
        $stmt->execute([$userId]);
        $stats = $stmt->fetch();

        $stmt = $pdo->prepare(
            "SELECT COUNT(DISTINCT oi.game_id)
             FROM orders o
             JOIN order_items oi ON oi.order_id = o.id
             WHERE o.user_id = ? AND o.status = 'paid'"
        );
        $stmt->execute([$userId]);
        $stats['owned_games'] = (int) $stmt->fetchColumn();

        $stmt = $pdo->prepare(
            "SELECT o.id, o.status, o.total_amount, o.created_at,
                    GROUP_CONCAT(
                        CONCAT(g.title, ' ×', oi.quantity)
                        ORDER BY g.title SEPARATOR ', '
                    ) AS items
             FROM orders o
             JOIN order_items oi ON oi.order_id = o.id
             JOIN games g ON g.id = oi.game_id
             WHERE o.user_id = ?
             GROUP BY o.id, o.status, o.total_amount, o.created_at
             ORDER BY o.id DESC LIMIT 5"
        );
        $stmt->execute([$userId]);
        $recentOrders = $stmt->fetchAll();

        require __DIR__ . '/../../views/profile/index.php';
    }
}
