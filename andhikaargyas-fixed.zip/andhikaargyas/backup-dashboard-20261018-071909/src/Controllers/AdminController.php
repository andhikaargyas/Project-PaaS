<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\Database;
use App\Models\User;

final class AdminController
{
    private static function authorize(): bool
    {
        if (empty($_SESSION['user_id'])) {
            header('Location: /login');
            return false;
        }

        $user = User::findById((int) $_SESSION['user_id']);

        if (!$user || $user['role'] !== 'admin') {
            http_response_code(403);
            echo '403 Forbidden: akses khusus admin.';
            return false;
        }

        return true;
    }

    private static function csrfToken(): string
    {
        if (empty($_SESSION['admin_csrf'])) {
            $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
        }

        return $_SESSION['admin_csrf'];
    }

    private static function verifyPost(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            exit('Method Not Allowed');
        }

        $submitted = (string) ($_POST['_csrf'] ?? '');
        $expected = (string) ($_SESSION['admin_csrf'] ?? '');

        if ($expected === '' || !hash_equals($expected, $submitted)) {
            http_response_code(419);
            exit('Token keamanan tidak valid. Muat ulang halaman.');
        }
    }

    private static function redirect(string $status): never
    {
        header('Location: /admin?status=' . rawurlencode($status));
        exit;
    }

    public static function index(): void
    {
        if (!self::authorize()) {
            return;
        }

        $games = Database::connection()
            ->query('SELECT * FROM games ORDER BY id DESC')
            ->fetchAll();

        $csrf = self::csrfToken();
        $status = (string) ($_GET['status'] ?? '');

        require dirname(__DIR__, 2) . '/views/admin/index.php';
    }

    public static function create(): void
    {
        if (!self::authorize()) {
            return;
        }

        self::verifyPost();

        $title = trim((string) ($_POST['title'] ?? ''));
        $slug = trim((string) ($_POST['slug'] ?? ''));
        $description = trim((string) ($_POST['description'] ?? ''));
        $price = filter_var($_POST['price'] ?? null, FILTER_VALIDATE_FLOAT);
        $developer = trim((string) ($_POST['developer'] ?? ''));
        $releaseDate = trim((string) ($_POST['release_date'] ?? ''));

        if (
            $title === '' || mb_strlen($title) > 200 ||
            !preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $slug) ||
            strlen($slug) > 150 ||
            $description === '' ||
            $price === false || $price < 0 || $price > 9999999999.99 ||
            mb_strlen($developer) > 150
        ) {
            self::redirect('invalid');
        }

        if ($releaseDate !== '') {
            $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $releaseDate);
            if (!$date || $date->format('Y-m-d') !== $releaseDate) {
                self::redirect('invalid');
            }
        } else {
            $releaseDate = null;
        }

        try {
            $stmt = Database::connection()->prepare(
                'INSERT INTO games
                    (slug, title, description, price, developer, release_date, is_active)
                 VALUES
                    (:slug, :title, :description, :price, :developer, :release_date, 1)'
            );

            $stmt->execute([
                'slug' => $slug,
                'title' => $title,
                'description' => $description,
                'price' => $price,
                'developer' => $developer !== '' ? $developer : null,
                'release_date' => $releaseDate,
            ]);
        } catch (\PDOException $e) {
            if ($e->getCode() === '23000') {
                self::redirect('duplicate');
            }
            throw $e;
        }

        self::redirect('created');
    }

    public static function update(): void
    {
        if (!self::authorize()) {
            return;
        }

        self::verifyPost();

        $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
        $title = trim((string) ($_POST['title'] ?? ''));
        $slug = trim((string) ($_POST['slug'] ?? ''));
        $description = trim((string) ($_POST['description'] ?? ''));
        $price = filter_var($_POST['price'] ?? null, FILTER_VALIDATE_FLOAT);
        $developer = trim((string) ($_POST['developer'] ?? ''));
        $releaseDate = trim((string) ($_POST['release_date'] ?? ''));

        if (
            !$id || $title === '' || mb_strlen($title) > 200 ||
            !preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $slug) ||
            strlen($slug) > 150 ||
            $description === '' ||
            $price === false || $price < 0 || $price > 9999999999.99 ||
            mb_strlen($developer) > 150
        ) {
            self::redirect('invalid');
        }

        if ($releaseDate !== '') {
            $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $releaseDate);
            if (!$date || $date->format('Y-m-d') !== $releaseDate) {
                self::redirect('invalid');
            }
        } else {
            $releaseDate = null;
        }

        try {
            $stmt = Database::connection()->prepare(
                'UPDATE games
                 SET slug = :slug, title = :title, description = :description,
                     price = :price, developer = :developer, release_date = :release_date
                 WHERE id = :id'
            );

            $stmt->execute([
                'slug' => $slug,
                'title' => $title,
                'description' => $description,
                'price' => $price,
                'developer' => $developer !== '' ? $developer : null,
                'release_date' => $releaseDate,
                'id' => $id,
            ]);
        } catch (\PDOException $e) {
            if ($e->getCode() === '23000') {
                self::redirect('duplicate');
            }
            throw $e;
        }

        self::redirect('updated');
    }

    public static function toggle(): void
    {
        if (!self::authorize()) {
            return;
        }

        self::verifyPost();

        $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);

        if (!$id) {
            self::redirect('invalid');
        }

        $stmt = Database::connection()->prepare(
            'UPDATE games SET is_active = NOT is_active WHERE id = :id'
        );
        $stmt->execute(['id' => $id]);

        self::redirect('toggled');
    }
}
