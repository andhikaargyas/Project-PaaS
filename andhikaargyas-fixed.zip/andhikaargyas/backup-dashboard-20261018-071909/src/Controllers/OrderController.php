<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\Database;
use App\Models\User;

final class OrderController
{
    private static function requireUser(): ?array
    {
        if (empty($_SESSION['user_id'])) {
            header('Location: /login');
            exit;
        }

        $user = User::findById((int) $_SESSION['user_id']);

        if (!$user) {
            session_regenerate_id(true);
            $_SESSION = [];
            header('Location: /login');
            exit;
        }

        return $user;
    }

    private static function verifyCsrf(): void
    {
        $submitted = (string) ($_POST['_csrf'] ?? '');
        $expected = (string) ($_SESSION['order_csrf'] ?? '');

        if ($expected === '' || !hash_equals($expected, $submitted)) {
            http_response_code(419);
            exit('Token keamanan tidak valid. Muat ulang halaman.');
        }
    }

    public static function buy(): void
    {
        self::requireUser();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            exit('Method Not Allowed');
        }

        self::verifyCsrf();

        $gameId = filter_var($_POST['game_id'] ?? null, FILTER_VALIDATE_INT);

        if (!$gameId) {
            header('Location: /?order=invalid');
            exit;
        }

        $pdo = Database::connection();
        $pdo->beginTransaction();

        try {
            $stmt = $pdo->prepare(
                'SELECT id, price FROM games WHERE id = ? AND is_active = 1'
            );
            $stmt->execute([$gameId]);
            $game = $stmt->fetch();

            if (!$game) {
                $pdo->rollBack();
                header('Location: /?order=unavailable');
                exit;
            }

            $stmt = $pdo->prepare(
                "INSERT INTO orders (user_id, status, total_amount)
                 VALUES (?, 'pending', ?)"
            );
            $stmt->execute([
                (int) $_SESSION['user_id'],
                $game['price'],
            ]);

            $orderId = (int) $pdo->lastInsertId();

            $stmt = $pdo->prepare(
                'INSERT INTO order_items
                    (order_id, game_id, price_at_purchase, quantity)
                 VALUES (?, ?, ?, 1)'
            );
            $stmt->execute([$orderId, $game['id'], $game['price']]);

            $pdo->commit();

            header('Location: /orders?id=' . $orderId);
            exit;
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    public static function index(): void
    {
        self::requireUser();

        $stmt = Database::connection()->prepare(
            'SELECT o.id, o.status, o.total_amount, o.created_at,
                    g.title, oi.quantity
             FROM orders o
             JOIN order_items oi ON oi.order_id = o.id
             JOIN games g ON g.id = oi.game_id
             WHERE o.user_id = ?
             ORDER BY o.id DESC'
        );
        $stmt->execute([(int) $_SESSION['user_id']]);
        $orders = $stmt->fetchAll();

        require dirname(__DIR__, 2) . '/views/orders/index.php';
    }

    public static function library(): void
    {
        self::requireUser();

        $stmt = Database::connection()->prepare(
            "SELECT DISTINCT g.id, g.slug, g.title, g.developer
             FROM orders o
             JOIN order_items oi ON oi.order_id = o.id
             JOIN games g ON g.id = oi.game_id
             WHERE o.user_id = ? AND o.status = 'paid'
             ORDER BY g.title"
        );
        $stmt->execute([(int) $_SESSION['user_id']]);
        $games = $stmt->fetchAll();

        require dirname(__DIR__, 2) . '/views/library/index.php';
    }
}
