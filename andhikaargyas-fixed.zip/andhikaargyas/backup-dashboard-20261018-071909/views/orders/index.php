<!doctype html>
<html lang="id">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pesanan Saya</title></head>
<body>
<h1>Pesanan Saya</h1>
<p><a href="/">Marketplace</a> · <a href="/library">Library game</a></p>
<?php if (!$orders): ?>
<p>Belum ada pesanan.</p>
<?php else: ?>
<table border="1" cellpadding="8">
<thead><tr><th>ID</th><th>Game</th><th>Jumlah</th><th>Total</th><th>Status</th><th>Dibuat</th></tr></thead>
<tbody>
<?php foreach ($orders as $order): ?>
<tr>
<td>#<?= (int) $order['id'] ?></td>
<td><?= htmlspecialchars($order['title'], ENT_QUOTES, 'UTF-8') ?></td>
<td><?= (int) $order['quantity'] ?></td>
<td>Rp <?= number_format((float) $order['total_amount'], 0, ',', '.') ?></td>
<td><?= htmlspecialchars($order['status'], ENT_QUOTES, 'UTF-8') ?></td>
<td><?= htmlspecialchars($order['created_at'], ENT_QUOTES, 'UTF-8') ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
<?php endif; ?>
</body>
</html>
