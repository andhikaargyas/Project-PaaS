<?php
use App\Services\Session;
$csrf = Session::csrfToken();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Profil | Andhika Games</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<main class="auth-container">
    <h1>Profil Pengguna</h1>

    <p>Nama:
        <?= htmlspecialchars($user['name'], ENT_QUOTES, 'UTF-8') ?>
    </p>
    <p>Email:
        <?= htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8') ?>
    </p>
    <p>Role:
        <?= htmlspecialchars($user['role'], ENT_QUOTES, 'UTF-8') ?>
    </p>
    <p>Akun dibuat:
        <?= htmlspecialchars($user['created_at'], ENT_QUOTES, 'UTF-8') ?>
    </p>

    <p>Koleksi game dan riwayat transaksi akan disambungkan setelah modul transaksi selesai.</p>
    <p><a href="/">Kembali ke katalog game</a></p>

    <form method="post" action="/logout">
        <input type="hidden" name="csrf_token"
               value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
        <button type="submit">Logout</button>
    </form>
</main>
</body>
</html>
