<?php
declare(strict_types=1);

function adminEscape(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$messages = [
    'created' => 'Game berhasil ditambahkan.',
    'updated' => 'Informasi game berhasil diperbarui.',
    'toggled' => 'Status game berhasil diubah.',
    'duplicate' => 'Slug game sudah digunakan.',
    'invalid' => 'Data tidak valid. Periksa kembali semua kolom.',
];
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Game - AndhikaArgyas</title>
    <link rel="stylesheet" href="/assets/style.css">
    <style>
        body{font-family:Arial,sans-serif;max-width:1200px;margin:30px auto;padding:0 18px}
        input,textarea{box-sizing:border-box;width:100%;padding:9px;margin:5px 0 12px}
        textarea{min-height:75px}
        .panel{border:1px solid #7775;border-radius:10px;padding:18px;margin:20px 0}
        .game{border-top:1px solid #7775;padding:18px 0}
        .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}
        button{padding:9px 15px;cursor:pointer}
        .notice{padding:12px;background:#d9f5df;color:#174d26;border-radius:6px}
        .inactive{opacity:.7}
    </style>
</head>
<body>
    <p><a href="/">← Marketplace</a> · <a href="/profile">Profil</a></p>
    <h1>Admin Panel — Pengelolaan Game</h1>

    <?php if (isset($messages[$status])): ?>
        <p class="notice"><?= adminEscape($messages[$status]) ?></p>
    <?php endif; ?>

    <section class="panel">
        <h2>Tambah game</h2>
        <form action="/admin/games/create" method="post">
            <input type="hidden" name="_csrf" value="<?= adminEscape($csrf) ?>">
            <div class="grid">
                <label>Judul
                    <input name="title" maxlength="200" required>
                </label>
                <label>Slug URL (contoh: minecraft)
                    <input name="slug" pattern="[a-z0-9]+(-[a-z0-9]+)*" maxlength="150" required>
                </label>
                <label>Harga (Rupiah)
                    <input name="price" type="number" min="0" step="0.01" required>
                </label>
                <label>Developer
                    <input name="developer" maxlength="150">
                </label>
                <label>Tanggal rilis
                    <input name="release_date" type="date">
                </label>
            </div>
            <label>Deskripsi
                <textarea name="description" required></textarea>
            </label>
            <button type="submit">Tambah game</button>
        </form>
    </section>

    <section class="panel">
        <h2>Daftar game (<?= count($games) ?>)</h2>

        <?php foreach ($games as $game): ?>
            <article class="game <?= empty($game['is_active']) ? 'inactive' : '' ?>">
                <h3>
                    <?= adminEscape($game['title']) ?>
                    <?= empty($game['is_active']) ? '(Nonaktif)' : '(Aktif)' ?>
                </h3>

                <form action="/admin/games/update" method="post">
                    <input type="hidden" name="_csrf" value="<?= adminEscape($csrf) ?>">
                    <input type="hidden" name="id" value="<?= (int) $game['id'] ?>">

                    <div class="grid">
                        <label>Judul
                            <input name="title" maxlength="200" value="<?= adminEscape($game['title']) ?>" required>
                        </label>
                        <label>Slug
                            <input name="slug" pattern="[a-z0-9]+(-[a-z0-9]+)*" maxlength="150" value="<?= adminEscape($game['slug']) ?>" required>
                        </label>
                        <label>Harga (Rupiah)
                            <input name="price" type="number" min="0" step="0.01" value="<?= adminEscape($game['price']) ?>" required>
                        </label>
                        <label>Developer
                            <input name="developer" maxlength="150" value="<?= adminEscape($game['developer'] ?? '') ?>">
                        </label>
                        <label>Tanggal rilis
                            <input name="release_date" type="date" value="<?= adminEscape($game['release_date'] ?? '') ?>">
                        </label>
                    </div>

                    <label>Deskripsi
                        <textarea name="description" required><?= adminEscape($game['description']) ?></textarea>
                    </label>
                    <button type="submit">Simpan perubahan</button>
                </form>

                <form action="/admin/games/toggle" method="post">
                    <input type="hidden" name="_csrf" value="<?= adminEscape($csrf) ?>">
                    <input type="hidden" name="id" value="<?= (int) $game['id'] ?>">
                    <button type="submit">
                        <?= empty($game['is_active']) ? 'Aktifkan game' : 'Nonaktifkan game' ?>
                    </button>
                </form>
            </article>
        <?php endforeach; ?>
    </section>
</body>
</html>
