<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars(
        $game['title'],
        ENT_QUOTES,
        'UTF-8'
    ) ?> | Andhika Store</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<header class="navbar">
    <a class="brand" href="/">ANDHIKA<span>STORE</span></a>
    <nav>
        <a href="/">Discover</a>
        <a href="/login">Login</a>
        <a class="button" href="/register">Join now</a>
    </nav>
</header>

<main class="container">
    <p class="breadcrumb"><a href="/">Discover</a> / Game details</p>

    <section class="detail">
        <div class="detail-cover">
            <span class="eyebrow">GAME DETAILS</span>
            <h1><?= htmlspecialchars(
                $game['title'],
                ENT_QUOTES,
                'UTF-8'
            ) ?></h1>
        </div>

        <div class="detail-info">
            <p class="eyebrow">ABOUT THIS GAME</p>
            <h2><?= htmlspecialchars(
                $game['title'],
                ENT_QUOTES,
                'UTF-8'
            ) ?></h2>

            <p><?= nl2br(htmlspecialchars(
                $game['description'],
                ENT_QUOTES,
                'UTF-8'
            )) ?></p>

            <dl>
                <dt>Developer</dt>
                <dd><?= htmlspecialchars(
                    $game['developer'] ?? 'Unknown',
                    ENT_QUOTES,
                    'UTF-8'
                ) ?></dd>

                <dt>Release date</dt>
                <dd><?= htmlspecialchars(
                    $game['release_date'] ?? 'Not specified',
                    ENT_QUOTES,
                    'UTF-8'
                ) ?></dd>
            </dl>

            <div class="purchase">
                <strong>Rp <?= number_format(
                    (float) $game['price'],
                    0,
                    ',',
                    '.'
                ) ?></strong>
                <a class="button" href="/login">Login to purchase</a>
            </div>
        </div>
    </section>
</main>

<footer>ANDHIKA STORE · GAME MARKETPLACE</footer>
</body>
</html>
