<!doctype html>
<html lang="id">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Library Game</title></head>
<body>
<h1>Library Game Saya</h1>
<p><a href="/">Marketplace</a> · <a href="/orders">Pesanan</a></p>
<p>Library hanya menampilkan game dari pesanan berstatus paid.</p>
<?php if (!$games): ?>
<p>Belum ada game di library.</p>
<?php else: ?>
<ul>
<?php foreach ($games as $game): ?>
<li>
<a href="/game/<?= rawurlencode($game['slug']) ?>">
<?= htmlspecialchars($game['title'], ENT_QUOTES, 'UTF-8') ?>
</a>
<?php if (!empty($game['developer'])): ?>
— <?= htmlspecialchars($game['developer'], ENT_QUOTES, 'UTF-8') ?>
<?php endif; ?>
</li>
<?php endforeach; ?>
</ul>
<?php endif; ?>
</body>
</html>
