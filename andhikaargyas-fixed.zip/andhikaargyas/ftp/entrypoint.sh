#!/usr/bin/env bash
set -euo pipefail

for username in karyawan pengelola; do
    env_name="FTP_PASSWORD_${username^^}"
    password="$(printenv "$env_name" || true)"

    if [[ ! "$username" =~ ^[a-z_][a-z0-9_-]*$ ]]; then
        echo "Nama pengguna FTP tidak valid."
        exit 1
    fi

    if [[ -z "$password" ]]; then
        echo "$env_name belum dikonfigurasi."
        exit 1
    fi

    if ! id "$username" >/dev/null 2>&1; then
        useradd --create-home --shell /bin/bash "$username"
    fi

    printf '%s:%s\n' "$username" "$password" | chpasswd

    install -d -o "$username" -g "$username" \
        "/home/$username/ftp"
    chmod 750 "/home/$username/ftp"
done

install -d -o root -g root -m 755 /var/run/vsftpd/empty

exec /usr/sbin/vsftpd /etc/vsftpd.conf
