#!/usr/bin/env bash
set -Eeuo pipefail

if ! getent group shareusers >/dev/null; then
    groupadd --system shareusers
fi

for username in karyawan pengelola; do
    env_name="SAMBA_PASSWORD_${username^^}"
    password="$(printenv "$env_name" || true)"

    if [[ -z "$password" ]]; then
        echo "$env_name wajib diatur."
        exit 1
    fi

    if ! id "$username" >/dev/null 2>&1; then
        useradd --no-create-home --shell /usr/sbin/nologin \
            --gid shareusers "$username"
    else
        usermod -aG shareusers "$username"
    fi

    printf '%s:%s\n' "$username" "$password" | chpasswd

    if pdbedit -L | cut -d: -f1 | grep -qx "$username"; then
        printf '%s\n%s\n' "$password" "$password" \
            | smbpasswd -s "$username"
    else
        printf '%s\n%s\n' "$password" "$password" \
            | smbpasswd -s -a "$username"
    fi
done

mkdir -p /shares/public
chgrp -R shareusers /shares/public
chmod -R g+rwX /shares/public
chmod 2770 /shares/public

testparm -s /etc/samba/smb.conf
exec smbd --foreground --no-process-group
