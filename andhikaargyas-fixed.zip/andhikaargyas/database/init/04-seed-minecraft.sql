USE marketplace;

INSERT INTO games
    (slug, title, description, price, developer, release_date)
VALUES
    ('minecraft', 'Minecraft',
     'Bangun, jelajahi, dan bertahan hidup di dunia berbentuk blok.',
     429000.00, 'Mojang Studios', '2011-11-18')
ON DUPLICATE KEY UPDATE
    title = VALUES(title),
    description = VALUES(description),
    developer = VALUES(developer);
