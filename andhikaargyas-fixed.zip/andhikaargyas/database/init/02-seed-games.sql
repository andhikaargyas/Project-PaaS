USE marketplace;

INSERT INTO games
    (slug, title, description, price, developer, release_date)
VALUES
    (
        'cyberpunk-2077',
        'Cyberpunk 2077',
        'Jelajahi Night City dalam RPG dunia terbuka futuristik.',
        699999.00,
        'CD PROJEKT RED',
        '2020-12-10'
    ),
    (
        'elden-ring',
        'Elden Ring',
        'Jelajahi Lands Between dalam petualangan action RPG.',
        599000.00,
        'FromSoftware',
        '2022-02-25'
    );
