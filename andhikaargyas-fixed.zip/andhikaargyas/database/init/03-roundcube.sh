#!/usr/bin/env bash
set -euo pipefail

: "${ROUNDCUBE_DB_PASSWORD:?ROUNDCUBE_DB_PASSWORD belum diisi}"

mariadb --protocol=socket -uroot \
    -p"${MARIADB_ROOT_PASSWORD}" <<SQL
CREATE DATABASE IF NOT EXISTS roundcube
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS 'roundcube_app'@'%'
    IDENTIFIED BY '${ROUNDCUBE_DB_PASSWORD}';

ALTER USER 'roundcube_app'@'%'
    IDENTIFIED BY '${ROUNDCUBE_DB_PASSWORD}';

GRANT ALL PRIVILEGES ON roundcube.*
    TO 'roundcube_app'@'%';

FLUSH PRIVILEGES;
SQL
